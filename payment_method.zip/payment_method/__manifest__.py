{
    "name": "Metodos de pago",
    "version": "13.0.0.1.0",
    "author": "jesus rodriguez",
    
    "license": "LGPL-3",
    "depends": [
        "account",
        
    ],
    "data": [
        # security
        # data
        # reports
        "reports/account_invoice_summary.xml",
        # views
        "views/account_invoice_summary.xml",
        "views/res_partner.xml",
    ],
}
